const axios = require('axios');
const IRCTC_BASE = 'https://irctc1.p.rapidapi.com/api/v1';
const RAPI_KEY = process.env.RAPIDAPI_IRCTC_KEY || '';

const headers = { 'X-RapidAPI-Key': RAPI_KEY, 'X-RapidAPI-Host': 'irctc1.p.rapidapi.com' };

module.exports.irctcExtended = {
  checkSeatAvailability: async (trainNo, source, destination, date, classCode, quota='GN')=>{
    if(!RAPI_KEY) return { error: 'Missing RAPIDAPI_IRCTC_KEY in env. This is a mock response.' };
    try{
      const res = await axios.get(`${IRCTC_BASE}/checkSeatAvailability?trainNo=${trainNo}&source=${source}&destination=${destination}&date=${date}&classCode=${classCode}&quota=${quota}`, { headers });
      return res.data;
    }catch(err){ return { error: err.message }; }
  },
  checkFare: async (trainNo, source, destination, age=25, quota='GN', classCode='SL', date)=>{
    if(!RAPI_KEY) return { error: 'Missing RAPIDAPI_IRCTC_KEY in env. This is a mock response.' };
    try{
      const res = await axios.get(`${IRCTC_BASE}/getFare?trainNo=${trainNo}&source=${source}&destination=${destination}&age=${age}&quota=${quota}&class=${classCode}&date=${date}`, { headers });
      return res.data;
    }catch(err){ return { error: err.message }; }
  },
  getPnrStatus: async (pnr)=>{
    if(!RAPI_KEY) return { error: 'Missing RAPIDAPI_IRCTC_KEY in env. This is a mock response.' };
    try{
      const res = await axios.get(`${IRCTC_BASE}/checkPNR?pnrNumber=${pnr}`, { headers });
      return res.data;
    }catch(err){ return { error: err.message }; }
  },
  getLiveStatus: async (trainNo, date)=>{
    if(!RAPI_KEY) return { error: 'Missing RAPIDAPI_IRCTC_KEY in env. This is a mock response.' };
    try{
      const res = await axios.get(`${IRCTC_BASE}/liveTrainStatus?trainNo=${trainNo}&date=${date}`, { headers });
      return res.data;
    }catch(err){ return { error: err.message }; }
  }
};
