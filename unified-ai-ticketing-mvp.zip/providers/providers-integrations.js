const axios = require('axios');

module.exports = {
  flight: {
    search: async (from,to,date)=>{
      // Mock unless AMADEUS credentials present
      if(!process.env.AMADEUS_API_KEY || !process.env.AMADEUS_API_SECRET){
        return { ok:true, results:[ { id:'FL1', airline:'Indigo', flightNo:'6E123', dep:'07:00', arr:'09:30', price:4500 } ]};
      }
      // Real Amadeus token + search could be placed here
      return { ok:false, error:'Amadeus credentials required for live search' };
    },
    book: async (flightId, passengers)=> ({ ok:true, bookingId:'FLBK'+Date.now(), pnr:'PNR'+Math.floor(Math.random()*100000) })
  },
  movie: {
    search: async (q)=>{
      if(!process.env.TMDB_API_KEY) return { ok:true, results:[ { id:'mv1', title:'Space Adventures' } ]};
      try{
        const res = await axios.get('https://api.themoviedb.org/3/search/movie', { params:{ api_key: process.env.TMDB_API_KEY, query: q }});
        return { ok:true, results: res.data.results };
      }catch(err){ return { ok:false, error: err.message }; }
    },
    getShowtimes: async (movieId, city)=> ({ ok:true, results:[ { theatre:'PVR Mall', time:'19:00', availableSeats:20 } ]}),
    book: async (showId, seats, user)=> ({ ok:true, bookingId:'MOV'+Date.now(), ticketIds: seats.map(s=>'T'+Math.floor(Math.random()*10000)) })
  },
  event: {
    search: async (q,city)=>{
      if(!process.env.EVENTBRITE_TOKEN) return { ok:true, results:[ { id:'ev1', name:'Comedy Night', venue:'TownHall', date:'2025-12-10' } ]};
      try{
        const res = await axios.get('https://www.eventbriteapi.com/v3/events/search/', { headers:{ Authorization: `Bearer ${process.env.EVENTBRITE_TOKEN}` }, params:{ q, 'location.address': city }});
        return { ok:true, results: res.data.events };
      }catch(err){ return { ok:false, error: err.message }; }
    },
    book: async (eventId, user)=> ({ ok:true, bookingId:'EV'+Date.now(), order:{ id:'ORD'+Math.floor(Math.random()*100000) } })
  }
};
