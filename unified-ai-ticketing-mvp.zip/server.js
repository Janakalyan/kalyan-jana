require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(require('cors')());

// Simple static frontend
app.use('/', express.static(path.join(__dirname, 'frontend')));

// Routers
const chatRouter = require('./routes/chat-intent-router');
app.use('/api', chatRouter);

const providersRouter = require('./routes/providers-router');
app.use('/api', providersRouter);

// Health
app.get('/api/health', (req,res)=> res.json({ok:true, ts:new Date().toISOString()}));

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> console.log(`Server running on http://localhost:${PORT}`));
