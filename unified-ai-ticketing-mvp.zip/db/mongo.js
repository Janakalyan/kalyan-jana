const mongoose = require('mongoose');

async function connectDB(){
  if(!process.env.MONGO_URI) return null;
  await mongoose.connect(process.env.MONGO_URI, { useNewUrlParser:true, useUnifiedTopology:true });
  console.log('MongoDB connected');
}

const ticketSchema = new mongoose.Schema({
  name:String,email:String,mode:String,from:String,to:String,date:String,seat:String,amount:Number,paymentId:String,orderId:String,pdfPath:String,createdAt:{type:Date,default:Date.now}
});
const Ticket = mongoose.models.Ticket || mongoose.model('Ticket', ticketSchema);

async function saveTicket(data){
  try{ const t = new Ticket(data); return await t.save(); }catch(e){ return null; }
}

module.exports = { connectDB, saveTicket, Ticket };
