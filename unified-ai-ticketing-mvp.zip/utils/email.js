const nodemailer = require('nodemailer');

async function emailTicket(toEmail, filePath){
  if(!process.env.EMAIL_USER || !process.env.EMAIL_PASS) return { error: 'EMAIL_USER/EMAIL_PASS not set (mock)' };
  const transporter = nodemailer.createTransport({ service:'gmail', auth:{ user:process.env.EMAIL_USER, pass:process.env.EMAIL_PASS }});
  const mailOptions = { from: process.env.EMAIL_USER, to: toEmail, subject: 'Your Ticket', text: 'Attached is your ticket', attachments:[ { filename: 'ticket.pdf', path: filePath } ] };
  return await transporter.sendMail(mailOptions);
}

module.exports = { emailTicket };
