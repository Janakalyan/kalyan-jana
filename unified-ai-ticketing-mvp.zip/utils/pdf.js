const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');
const QRCode = require('qrcode');

function generateTicketPDF(ticketData){
  if(!fs.existsSync('tickets')) fs.mkdirSync('tickets');
  const filePath = path.join('tickets', `ticket_${Date.now()}.pdf`);
  const doc = new PDFDocument({ margin: 40 });
  const stream = fs.createWriteStream(filePath);
  doc.pipe(stream);
  doc.fontSize(20).text('Unified AI Ticket', { align: 'center' });
  doc.moveDown();
  doc.fontSize(12).text('Name: '+(ticketData.name||''));
  doc.text('Mode: '+(ticketData.mode||''));
  doc.text('From: '+(ticketData.from||''));
  doc.text('To: '+(ticketData.to||''));
  doc.text('Date: '+(ticketData.date||''));
  doc.text('Seat: '+(ticketData.seat||''));
  doc.text('Price Paid: ₹'+(ticketData.amount||''));
  doc.moveDown();

  // embed QR
  const ticketUrl = ticketData.ticketUrl || '';
  return new Promise((resolve,reject)=>{
    QRCode.toDataURL(ticketUrl || 'https://example.com').then(dataUrl=>{
      const base64 = dataUrl.replace(/^data:image\/(png|jpeg);base64,/, '');
      const buffer = Buffer.from(base64,'base64');
      doc.image(buffer, { fit:[120,120], align:'center' });
      doc.end();
      stream.on('finish', ()=> resolve(filePath));
      stream.on('error', reject);
    }).catch(err=>{
      doc.end();
      stream.on('finish', ()=> resolve(filePath));
      stream.on('error', reject);
    });
  });
}

module.exports = { generateTicketPDF };
