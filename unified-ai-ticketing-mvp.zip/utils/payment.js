const Razorpay = require('razorpay');
const crypto = require('crypto');

const razorpay = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID || '', key_secret: process.env.RAZORPAY_KEY_SECRET || '' });

async function createPaymentOrder(amount, currency='INR'){
  if(!process.env.RAZORPAY_KEY_ID) return { error: 'Razorpay credentials missing (mock mode)' };
  const options = { amount: Math.round(amount*100), currency, receipt: 'rcpt_'+Date.now() };
  return await razorpay.orders.create(options);
}

function verifyPaymentSignature({ orderId, paymentId, signature }){
  const body = orderId + '|' + paymentId;
  const expected = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET || '').update(body).digest('hex');
  return expected === signature;
}

module.exports = { createPaymentOrder, verifyPaymentSignature };
