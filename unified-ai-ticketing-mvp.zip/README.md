# Unified AI Ticketing MVP — ZIP Bundle

This project is a local MVP skeleton for a unified ticketing chatbot (movies, trains, buses, events, flights).
It includes:
- Express backend with IRCTC provider hooks, bus mock, movie/event/flight adapters
- Chat intent router that handles train-seat/fare/pnr/live queries
- Bus search, seat-layout, booking, PDF generation and email sending hooks
- Razorpay order helper (mock if keys missing)
- MongoDB saving utilities

## Setup

1. Copy `.env.example` to `.env` and fill needed keys.
2. `npm install`
3. `node server.js`
4. Open `http://localhost:4000/` in your browser.

## Notes
- This project uses mocks for many providers. Replace provider keys in `.env` to enable real integrations.
- Do NOT commit your real API keys.

