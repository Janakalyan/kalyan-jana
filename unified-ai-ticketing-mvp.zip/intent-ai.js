function detectIntent(text){
  const t = (text||'').toLowerCase();
  if(/seat.*availability/.test(t) || (t.includes('seat') && t.includes('availability'))) return 'seat_availability';
  if(/fare|ticket price/.test(t)) return 'fare_enquiry';
  if(/pnr/.test(t)) return 'pnr_status';
  if(/live.*status/.test(t) || (t.includes('live') && t.includes('status'))) return 'live_status';
  return 'unknown';
}
module.exports = { detectIntent };
