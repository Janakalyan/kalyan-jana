const chat = document.getElementById('chat');
const inp = document.getElementById('inp');
const send = document.getElementById('send');

function add(msg, cls){ const d=document.createElement('div'); d.className='msg '+cls; d.innerText=msg; chat.appendChild(d); chat.scrollTop = chat.scrollHeight; }

send.onclick = async ()=> {
  const text = inp.value.trim(); if(!text) return;
  add(text,'me'); inp.value='';
  const res = await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body: JSON.stringify({ message: text })}).then(r=>r.json());
  add(JSON.stringify(res), 'bot');
};
