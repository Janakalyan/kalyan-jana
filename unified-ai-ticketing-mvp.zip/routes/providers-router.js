const express = require('express');
const router = express.Router();
const providers = require('../providers/providers-integrations');
const pdfUtil = require('../utils/pdf');
const emailUtil = require('../utils/email');
const payment = require('../utils/payment');
const db = require('../db/mongo');

// Flight search (uses providers file)
router.get('/flight/search', async (req,res)=>{
  const { from, to, date } = req.query;
  const out = await providers.flight.search(from,to,date);
  res.json(out);
});

router.post('/flight/book', async (req,res)=>{
  const { flightId, passengers } = req.body;
  const out = await providers.flight.book(flightId, passengers);
  res.json(out);
});

// Movie endpoints
router.get('/movie/search', async (req,res)=>{
  const { q } = req.query;
  const out = await providers.movie.search(q);
  res.json(out);
});
router.get('/movie/showtimes', async (req,res)=>{
  const { movieId, city } = req.query;
  const out = await providers.movie.getShowtimes(movieId, city);
  res.json(out);
});
router.post('/movie/book', async (req,res)=>{
  const { showId, seats, user } = req.body;
  const out = await providers.movie.book(showId,seats,user);
  res.json(out);
});

// Event endpoints
router.get('/event/search', async (req,res)=>{
  const { q, city } = req.query;
  const out = await providers.event.search(q,city);
  res.json(out);
});
router.post('/event/book', async (req,res)=>{
  const { eventId, user } = req.body;
  const out = await providers.event.book(eventId,user);
  res.json(out);
});

// Bus handlers (exposed as functions for chat-intent-router)
async function handleBusSearch(req,res){
  const { from, to, date } = req.body;
  if(!from||!to||!date) return res.json({ error: 'Missing from/to/date' });
  // sample/mock results
  const sample = [
    { operator: 'Sharma Travels', busType: 'A/C Sleeper', departure: '22:00', arrival:'07:00', seatsAvailable:14, price:1299, busId:'BUS123'},
    { operator: 'Royal Cruiser', busType: 'Non A/C Seater', departure: '18:30', arrival:'05:00', seatsAvailable:23, price:999, busId:'BUS456'}
  ];
  return res.json({ ok:true, results: sample });
}

async function handleBusSeatLayout(req,res){
  const { busId, date } = req.body;
  if(!busId||!date) return res.json({ error: 'Missing busId/date' });
  const layout = { busId, deck:'single', seats:[
    { seatNo:'A1', type:'Sleeper', available:true, price:1299 },
    { seatNo:'A2', type:'Sleeper', available:false, price:1299 },
    { seatNo:'B1', type:'Seater', available:true, price:999 },
    { seatNo:'B2', type:'Seater', available:true, price:999 }
  ]};
  return res.json({ ok:true, layout });
}

async function handleBusBook(req,res){
  const { busId, seatNo, passenger, date } = req.body;
  if(!busId||!seatNo||!passenger||!date) return res.json({ error:'Missing busId/seatNo/passenger/date' });
  const booking = { bookingId:'BK'+Math.floor(Math.random()*1000000), busId, seatNo, passenger, date, status:'CONFIRMED', amount: passenger.fare || 1299 };
  // Save to DB if connected
  try{ if(db.saveTicket) await db.saveTicket({ name: passenger.name, email: passenger.email, mode:'bus', from: passenger.from||'', to: passenger.to||'', date, seat:seatNo, amount: booking.amount, paymentId:null, orderId:null, pdfPath:null }); }catch(e){}
  return res.json({ ok:true, booking });
}

async function handleBusPdf(req,res){
  const { booking } = req.body;
  if(!booking) return res.json({ error:'Missing booking' });
  // generate pdf file path
  try{
    const filePath = pdfUtil.generateTicketPDF({ name: booking.passenger.name, mode:'bus', from: booking.passenger.from||'', to: booking.passenger.to||'', date: booking.date, seat: booking.seatNo, amount: booking.amount });
    // optionally email
    if(booking.passenger && booking.passenger.email){
      await emailUtil.emailTicket(booking.passenger.email, filePath);
    }
    return res.json({ ok:true, filePath });
  }catch(err){
    return res.json({ error: err.message });
  }
}

async function handleChatBus(req,res){
  const message = (req.body.message||'').toLowerCase();
  if(message.includes('from') && message.includes('to')){
    return res.redirect(307, '/api/bus');
  }
  if(message.includes('seat') || message.includes('layout')) return res.redirect(307,'/api/bus/seat-layout');
  if(message.includes('book') && message.includes('seat')) return res.redirect(307,'/api/bus/book');
  return res.json({ reply:'I can help with bus search, seat layout and booking.' });
}

module.exports = { router, handleBusSearch, handleBusSeatLayout, handleBusBook, handleBusPdf, handleChatBus };
