const express = require('express');
const router = express.Router();
const { irctcExtended } = require('../providers/irctc');
const { detectIntent } = require('../intent-ai');

// Simple chat endpoint that routes by intent
router.post('/chat', async (req, res) => {
  const { message } = req.body;
  const text = (message || '').toLowerCase();
  try {
    const intent = detectIntent(text);
    if (intent === 'seat_availability') {
      const trainNo = text.match(/\d{5}/)?.[0];
      const date = text.match(/\d{4}-\d{2}-\d{2}/)?.[0];
      const out = await irctcExtended.checkSeatAvailability(trainNo, 'HWH', 'NDLS', date, 'SL');
      return res.json({ intent, out });
    }
    if (intent === 'fare_enquiry') {
      const trainNo = text.match(/\d{5}/)?.[0];
      const date = text.match(/\d{4}-\d{2}-\d{2}/)?.[0];
      const out = await irctcExtended.checkFare(trainNo, 'HWH', 'NDLS', 25, 'GN', 'SL', date);
      return res.json({ intent, out });
    }
    if (intent === 'pnr_status') {
      const pnr = text.match(/\d{10}/)?.[0];
      const out = await irctcExtended.getPnrStatus(pnr);
      return res.json({ intent, out });
    }
    if (intent === 'live_status') {
      const trainNo = text.match(/\d{5}/)?.[0];
      const out = await irctcExtended.getLiveStatus(trainNo, new Date().toISOString().split('T')[0]);
      return res.json({ intent, out });
    }
    return res.json({ intent: 'unknown', reply: 'I can help with seat availability, fare, PNR and live status. Try: "seat availability 12841 2025-12-01"' });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// Bus endpoints integrated here for simplicity
const providers = require('./providers-router');
router.post('/bus', (req,res)=> providers.handleBusSearch(req,res));
router.post('/bus/seat-layout', (req,res)=> providers.handleBusSeatLayout(req,res));
router.post('/bus/book', (req,res)=> providers.handleBusBook(req,res));
router.post('/bus/ticket/pdf', (req,res)=> providers.handleBusPdf(req,res));
router.post('/chat/bus', (req,res)=> providers.handleChatBus(req,res));

module.exports = router;
